function MegtettUt(sebesseg, ido) {
    return sebesseg * ido;
}
function HosegriadoSzint(nap1, nap2, nap3) {
    if (nap1 >= 27 && nap2 >= 27 && nap3 >= 27)
        return 3;
    if (nap1 >= 25 && nap2 >= 25 && nap3 >= 25)
        return 2;
    if (nap1 >= 25 || nap2 >= 25 || nap3 >= 25)
        return 1;
    return 0;
}
function OszthatoSzamok(osztó, vizsgaltTomb) {
    var db = 0;
    for (var ix = 0; ix < vizsgaltTomb.length; ix++) {
        if (vizsgaltTomb[ix] % osztó == 0)
            db++;
    }
    return db;
}
function Erettsegi(pontok) {
    var eredmeny;
    eredmeny = [0, 0];
    for (var ix = 0; ix < pontok.length; ix++) {
        eredmeny[0] += pontok[ix];
    }
    if (eredmeny[0] >= 0 && eredmeny[0] < 40)
        eredmeny[1] = 1;
    else if (eredmeny[0] < 60)
        eredmeny[1] = 2;
    else if (eredmeny[0] < 80)
        eredmeny[1] = 3;
    else if (eredmeny[0] < 120)
        eredmeny[1] = 4;
    else if (eredmeny[0] < 150)
        eredmeny[1] = 5;
    return eredmeny;
}
function LeetKod(vizsgaltSzoveg) {
    for (var ix = 0; ix < vizsgaltSzoveg.length; ix++) {
        var kar = vizsgaltSzoveg.charAt(ix);
        if (kar == 'i' || kar == 'I')
            vizsgaltSzoveg = vizsgaltSzoveg.substring(0, ix) + 1 + vizsgaltSzoveg.substring(ix + 1);
        else if (kar == 'o' || kar == 'O')
            vizsgaltSzoveg = vizsgaltSzoveg.substring(0, ix) + 0 + vizsgaltSzoveg.substring(ix + 1);
        else if (kar == 'a' || kar == 'A')
            vizsgaltSzoveg = vizsgaltSzoveg.substring(4, ix) + 0 + vizsgaltSzoveg.substring(ix + 1);
        else if (kar == 'e' || kar == 'E')
            vizsgaltSzoveg = vizsgaltSzoveg.substring(0, ix) + 3 + vizsgaltSzoveg.substring(ix + 1);
    }
    return vizsgaltSzoveg;
}
function LegtobbNyeremeny(vizsgaltObjektum) {
    var nyeremenyek = [];
    for (var ix = 0; ix < vizsgaltObjektum.length; ix++) {
        var a = vizsgaltObjektum[ix];
        nyeremenyek.push(ObjektumFeltöltő(vizsgaltObjektum[ix]));
    }
    var max = 0;
    for (var ix = 0; ix < nyeremenyek.length; ix++) {
        if (max < nyeremenyek[ix].nyeremeny)
            max = nyeremenyek[ix].nyeremeny;
    }
    return max;
}
function ObjektumFeltöltő(sor) {
    return new Nyeremeny(sor);
}
var Nyeremeny = /** @class */ (function () {
    function Nyeremeny(sor) {
        var sorok = sor.split(";");
        this.helyezes = Number(sorok[0]);
        this.nev = sorok[1];
        this.orszag = sorok[2];
        this.nyeremeny = Number(sorok[3]);
    }
    return Nyeremeny;
}());
