function MegtettUt(sebesseg: number, ido: number): number {
  return sebesseg * ido;
}

function HosegriadoSzint(nap1: number, nap2: number, nap3: number): number {
  if (nap1 >= 27 && nap2 >= 27 && nap3 >= 27) return 3;
  if (nap1 >= 25 && nap2 >= 25 && nap3 >= 25) return 2;
  if (nap1 >= 25 || nap2 >= 25 || nap3 >= 25) return 1;
  return 0;
}

function OszthatoSzamok(osztó: number, vizsgaltTomb: number[]) {
  let db = 0;
  for (let ix = 0; ix < vizsgaltTomb.length; ix++) {
    if (vizsgaltTomb[ix] % osztó == 0) db++;
  }
  return db;
}

function Erettsegi(pontok: number[]) {
  let eredmeny: [összpontszám: number, jegy: number];
  eredmeny = [0, 0];
  for (let ix = 0; ix < pontok.length; ix++) {
    eredmeny[0] += pontok[ix];
  }
  if (eredmeny[0] >= 0 && eredmeny[0] < 40) eredmeny[1] = 1;
  else if (eredmeny[0] < 60) eredmeny[1] = 2;
  else if (eredmeny[0] < 80) eredmeny[1] = 3;
  else if (eredmeny[0] < 120) eredmeny[1] = 4;
  else if (eredmeny[0] < 150) eredmeny[1] = 5;
  return eredmeny;
}

function LeetKod(vizsgaltSzoveg:string) {
    for (let ix = 0; ix < vizsgaltSzoveg.length; ix++) {
        let kar: string=vizsgaltSzoveg.charAt(ix)
        if(kar=='i'||kar=='I')
            vizsgaltSzoveg=vizsgaltSzoveg.substring(0,ix)+1+vizsgaltSzoveg.substring(ix+1)
        else if(kar=='o'||kar=='O')
            vizsgaltSzoveg=vizsgaltSzoveg.substring(0,ix)+0+vizsgaltSzoveg.substring(ix+1)
        else if(kar=='a'||kar=='A')
            vizsgaltSzoveg=vizsgaltSzoveg.substring(4,ix)+0+vizsgaltSzoveg.substring(ix+1)
        else if(kar=='e'||kar=='E')
            vizsgaltSzoveg=vizsgaltSzoveg.substring(0,ix)+3+vizsgaltSzoveg.substring(ix+1)
    }
    return vizsgaltSzoveg
}

function LegtobbNyeremeny(vizsgaltObjektum:string[]) {
    let nyeremenyek: Nyeremeny[] = []
    for (let ix = 0; ix < vizsgaltObjektum.length; ix++) {
        let a=vizsgaltObjektum[ix]
        nyeremenyek.push(ObjektumFeltöltő(vizsgaltObjektum[ix]))
    }
    
    let max: number=0
    for (let ix = 0; ix < nyeremenyek.length; ix++) {
        if(max<nyeremenyek[ix].nyeremeny)
            max=nyeremenyek[ix].nyeremeny
    }
    return max
}

function ObjektumFeltöltő(sor:string): Nyeremeny {
   
    return new Nyeremeny(sor)
}

class Nyeremeny{
    helyezes:number
    nev:string
    orszag:string
    nyeremeny:number

    constructor(sor){
        let sorok:string[]=sor.split(";")
        this.helyezes=Number(sorok[0])
        this.nev=sorok[1]
        this.orszag=sorok[2]
        this.nyeremeny=Number(sorok[3])

    }
    
}